using UnityEngine;
using DG.Tweening;

public class JumpBlob : MonoBehaviour
{
    [Header("HAUTEURS")]
    [SerializeField] private float groundLevel = 0.5f;   
    [SerializeField] private float ceilingLevel = 4.5f;  

    [Header("ANIMATION")]
    [SerializeField] private float jumpDuration = 0.3f;  
    [SerializeField] private float rotateDuration = 0.2f; 

    private bool isCeiling = false;  
    private bool isJumping = false;  

    public bool IsCeiling => isCeiling;

    public void Jump()
    {
        if (isJumping) return;
        isJumping = true;

        Sequence jumpSeq = DOTween.Sequence();

        if (!isCeiling)
        {
            jumpSeq.Join(transform.DOLocalRotate(new Vector3(180, 0, 0), rotateDuration));
            jumpSeq.Join(transform.DOMoveY(ceilingLevel, jumpDuration));
            isCeiling = true;
        }
        else
        {
            jumpSeq.Join(transform.DOLocalRotate(new Vector3(0, 0, 0), rotateDuration));
            jumpSeq.Join(transform.DOMoveY(groundLevel, jumpDuration));
            isCeiling = false;
        }

        jumpSeq.OnComplete(() => isJumping = false);
    }
}
using UnityEngine;
using System.Collections.Generic;

public class ChunkManager : MonoBehaviour
{
    [Header("Prefabs de Couloirs")]
    [SerializeField] private GameObject[] couloirPrefabs;

    [Header("Param�tres")]
    [SerializeField] private Transform player;
    [SerializeField] private int chunksVisibles = 3;
    [SerializeField] private float longueurCouloir = 180f;
    [SerializeField] private float distanceDeclenchement = 50f;

    private Queue<GameObject> chunksActifs = new Queue<GameObject>();
    private float prochainePositionZ = 0f;

    void Start()
    {
        if (couloirPrefabs.Length == 0)
        {
            Debug.LogError("Aucun prefab de couloir assign�!");
            return;
        }

        for (int i = 0; i < chunksVisibles; i++)
        {
            GenererChunk();
        }
    }

    void Update()
    {
        if (player == null) return;

        if (player.position.z > prochainePositionZ - distanceDeclenchement)
        {
            GenererChunk();
            SupprimerChunk();
        }
    }

    void GenererChunk()
    {
        GameObject prefab = couloirPrefabs[Random.Range(0, couloirPrefabs.Length)];

        Vector3 position = new Vector3(0, 0, prochainePositionZ);
        GameObject nouveauChunk = Instantiate(prefab, position, Quaternion.identity);

        chunksActifs.Enqueue(nouveauChunk);
        prochainePositionZ += longueurCouloir;

        Debug.Log("Chunk g�n�r� � Z: " + position.z);
    }

    void SupprimerChunk()
    {
        if (chunksActifs.Count > chunksVisibles)
        {
            GameObject ancienChunk = chunksActifs.Dequeue();
            Destroy(ancienChunk);
        }
    }
}
using UnityEngine;

public class HorizontalLaser : BaseLaser
{
    [Header("Configuration Position")]
    [SerializeField] private float groundLevel = 0f; 
    [SerializeField] private float ceilingLevel = 5f; 
    [SerializeField] private bool isCeilingLaser = false; 

    [Header("Configuration Taille")]
    [SerializeField] private float laserLength = 10f; 
    [SerializeField] private float laserThickness = 0.1f; 
    [SerializeField] private float laserDepth = 0.1f; 

    [Header("R�f�rences")]
    [SerializeField] private LineRenderer lineRenderer; 
    [SerializeField] private BoxCollider laserCollider; 

    
    private void Start()
    {
        InitializeLaser(); 
    }

    private void InitializeLaser()
    {
        float yPosition = isCeilingLaser ? ceilingLevel : groundLevel;
        transform.position = new Vector3(transform.position.x, yPosition, transform.position.z);

        laserCollider.size = new Vector3(laserLength, laserThickness, laserDepth);

        laserCollider.center = new Vector3(laserLength * 0.5f, 0, 0);

        lineRenderer.positionCount = 2; 
        lineRenderer.SetPosition(0, Vector3.zero); 
        lineRenderer.SetPosition(1, new Vector3(laserLength, 0, 0)); 
    }

    private void OnTriggerStay(Collider other)
    {
        if (((1 << other.gameObject.layer) & playerMask) != 0)
        {
            BiomassManager biomass = other.GetComponent<BiomassManager>();
            if (biomass != null)
            {
                if (!CanPlayerDodge(biomass))
                {
                    ApplyDamage(biomass); 
                }
            }
        }
    }

    private bool CanPlayerDodge(BiomassManager player)
    {
        JumpBlob jumpSystem = player.GetComponent<JumpBlob>();
        if (jumpSystem == null) return false;

        if (isCeilingLaser)
        {
            return !jumpSystem.IsCeiling;
        }
        else
        {
            return jumpSystem.IsCeiling;
        }
    }
}
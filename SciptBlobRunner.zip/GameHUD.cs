using UnityEngine;
using TMPro;
using UnityEngine.UI;

public class GameHUD : MonoBehaviour
{
    [Header("BIOMASSE")]
    public Slider biomassSlider;
    public Image biomassFill;
    public Color lowBiomassColor = Color.red;
    public Color mediumBiomassColor = Color.yellow;
    public Color highBiomassColor = Color.green;

    [Header("COMPTEURS")]
    public TextMeshProUGUI coinText;
    public TextMeshProUGUI bigResourceText;
    public TextMeshProUGUI distanceText;

    [Header("INDICATEUR DE FORME")]
    public TextMeshProUGUI shapeText;
    public Image shapeIcon;

    [Header("COULEURS DES FORMES")]
    public Color shape0Color = Color.blue;
    public Color shape1Color = Color.green;
    public Color shape2Color = Color.yellow;
    public Color shape3Color = Color.red;

    private int currentCoins = 0;
    private int currentBigResources = 0;
    private float currentDistance = 0f;
    private int currentShape = 0;

    void Start()
    {
        InitializeHUD(); 
    }

    void InitializeHUD()
    {
        if (biomassSlider != null)
        {
            biomassSlider.minValue = 0;
            biomassSlider.maxValue = 300;
            biomassSlider.value = 0; 
        }

        UpdateBiomassColor(0); 
        UpdateCoinCounter(0); 
        UpdateBigResourceCounter(0); 
        UpdateDistance(0f);
        UpdateShapeIndicator(0);
    }

    public void UpdateBiomass(int biomass)
    {
        if (biomassSlider != null)
        {
            biomassSlider.value = biomass; 
        }
        UpdateBiomassColor(biomass); 

        int newShape = GetCurrentShape(biomass);
        if (newShape != currentShape) 
        {
            currentShape = newShape; 
            UpdateShapeIndicator(currentShape); 
        }
    }

    void UpdateBiomassColor(int biomass)
    {
        if (biomassFill == null) return; 

        if (biomass >= 150) 
            biomassFill.color = highBiomassColor; 
        else if (biomass >= 50) 
            biomassFill.color = mediumBiomassColor;
        else 
            biomassFill.color = lowBiomassColor;
    }

    int GetCurrentShape(int biomass)
    {
        if (biomass >= 300) return 3;
        if (biomass >= 150) return 2; 
        if (biomass >= 50) return 1; 
        return 0; 
    }

    public void UpdateShapeIndicator(int shape)
    {
        if (shapeText != null)
        {
            shapeText.text = $"Forme {shape}"; 
        }

        if (shapeIcon != null)
        {
            switch (shape)
            {
                case 0:
                    shapeIcon.color = shape0Color; 
                    break;
                case 1:
                    shapeIcon.color = shape1Color; 
                    break;
                case 2:
                    shapeIcon.color = shape2Color; 
                    break;
                case 3:
                    shapeIcon.color = shape3Color; 
                    break;
                default:
                    shapeIcon.color = Color.white; 
                    break;
            }
        }
    }

    public void UpdateCoinCounter(int coins)
    {
        currentCoins = coins;
        if (coinText != null)
        {
            coinText.text = $"Pi�ces: {coins}"; 
        }
    }

    public void UpdateBigResourceCounter(int bigResources)
    {
        currentBigResources = bigResources;
        if (bigResourceText != null)
        {
            bigResourceText.text = $"Ressources: {bigResources}"; 
        }
    }

    
    public void UpdateDistance(float distance)
    {
        currentDistance = distance; 
        if (distanceText != null)
        {
            distanceText.text = $"Distance: {distance:F0}m"; 
        }
    }

    public void AddCoin()
    {
        currentCoins++; 
        if (coinText != null)
        {
            coinText.text = $"Pi�ces: {currentCoins}"; 
        }
    }

    public void AddBigResource()
    {
        currentBigResources++; 
        if (bigResourceText != null)
        {
            bigResourceText.text = $"Ressources: {currentBigResources}"; 
        }
    }
}
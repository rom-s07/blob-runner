using UnityEngine;
using System.Collections;

public class PorteAutomatique : MonoBehaviour
{
    [Header("Param�tres d'Animation de la Porte")]
    [SerializeField] private float distanceOuverture = 3f; 
    [SerializeField] private float dureeOuverture = 1f; 
    [SerializeField] private bool ouvrirAGauche = true; 

    [Header("Param�tres de D�g�ts")]
    [SerializeField] private LayerMask playerMask; 

    [Header("R�f�rences aux Composants")]
    [SerializeField] private Collider colliderPorte; 

    private bool estOuverte = false; 
    private Vector3 positionFermee; 
    private Vector3 positionOuverte; 

    void Start()
    {
        positionFermee = transform.position;

        float direction = ouvrirAGauche ? -1f : 1f;

        positionOuverte = positionFermee + new Vector3(distanceOuverture * direction, 0, 0);
    }

    private void OnTriggerEnter(Collider other)
    {
        if (!estOuverte && (((1 << other.gameObject.layer) & playerMask) != 0))
        {
            BiomassManager biomass = other.GetComponent<BiomassManager>();
            if (biomass != null)
            {
                biomass.TakeObstacleDamage();
                Debug.Log("Blob a touch� une porte ferm�e! -50 biomasse");
            }
        }
    }

    public void OuvrirPorte()
    {
        if (estOuverte) return;

        estOuverte = true;
        Debug.Log($"{name} commence � s'ouvrir vers {(ouvrirAGauche ? "gauche" : "droite")}!");

        if (colliderPorte != null)
        {
            colliderPorte.enabled = false; 
        }

        StartCoroutine(AnimationOuverture());
    }

    private IEnumerator AnimationOuverture()
    {
        float timer = 0f; 

        while (timer < dureeOuverture)
        {
            timer += Time.deltaTime;

            float progression = timer / dureeOuverture;

            transform.position = Vector3.Lerp(positionFermee, positionOuverte, progression);

            yield return null;
        }

        transform.position = positionOuverte;

        Debug.Log($"{name} est maintenant compl�tement ouverte!");
    }

    public bool EstOuverte()
    {
        return estOuverte;
    }
}
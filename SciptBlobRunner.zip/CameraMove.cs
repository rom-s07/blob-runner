using UnityEngine;

public class CameraFollow : MonoBehaviour
{
    [Header("Cible � Suivre")]
    [SerializeField] private Transform target; 

    [Header("Param�tres de Position Fixe")]
    [SerializeField] private Vector3 positionRelative = new Vector3(0, 3f, -5f); 
    [SerializeField] private float smoothSpeed = 5f; 

    [Header("Inclinaison Plafond")]
    [SerializeField] private float inclinationPlafond = 15f; 
    [SerializeField] private float vitesseInclinaison = 3f; 

    private JumpBlob jumpSystem; 
    private Quaternion rotationNormale; 
    private Quaternion rotationInclinee; 

    private void Start()
    {
        if (target == null)
        {
            Debug.LogError("Target non assign�e dans CameraFollow!");
            return;
        }

        jumpSystem = target.GetComponent<JumpBlob>();
        if (jumpSystem == null)
        {
            Debug.LogWarning(" JumpBlob non trouv� sur la cible - l'inclinaison ne fonctionnera pas");
        }

        InitialiserPositionCamera();

        InitialiserRotations();
    }

    private void InitialiserPositionCamera()
    {
        transform.position = target.position + positionRelative;
        Debug.Log($" Cam�ra initialis�e �: {transform.position}");
    }

    private void InitialiserRotations()
    {
        rotationNormale = Quaternion.Euler(0, 0, 0);

        rotationInclinee = Quaternion.Euler(inclinationPlafond, 0, 0);

        transform.rotation = rotationNormale;
    }

    private void LateUpdate()
    {
        if (target == null) return; 

        GererPositionCamera();

        GererRotationCamera();
    }

    private void GererPositionCamera()
    {
        Vector3 positionCible = new Vector3(
            target.position.x + positionRelative.x, 
            transform.position.y,                   
            target.position.z + positionRelative.z  
        );

        Vector3 positionLisse = Vector3.Lerp(transform.position, positionCible, smoothSpeed * Time.deltaTime);

        transform.position = positionLisse;
    }

    private void GererRotationCamera()
    {
        bool blobAuPlafond = jumpSystem != null && jumpSystem.IsCeiling;

        Quaternion rotationCible = blobAuPlafond ? rotationInclinee : rotationNormale;

        transform.rotation = Quaternion.Slerp(transform.rotation, rotationCible, vitesseInclinaison * Time.deltaTime);
    }
}
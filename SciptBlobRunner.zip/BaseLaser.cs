using UnityEngine;

public  class BaseLaser : MonoBehaviour
{
    [Header("Param�tres Laser Communs")]
    [SerializeField] protected int biomassDamage = 50;
    [SerializeField] protected float damageCooldown = 0.5f;
    [SerializeField] protected LayerMask playerMask;
    [SerializeField] protected float puddleModeThreshold = 0.5f;

    protected float lastDamageTime;
    protected BiomassManager currentTarget;

    protected void ApplyDamage(BiomassManager target)
    {
        if (target != null && Time.time >= lastDamageTime + damageCooldown)
        {
            target.TakeObstacleDamage();
            lastDamageTime = Time.time; 
            Debug.Log($"Touch� par laser! -{biomassDamage} biomasse");
        }
    }

    protected bool IsBlobInPuddleMode()
    {
        return transform.localScale.y < puddleModeThreshold;
    }
}
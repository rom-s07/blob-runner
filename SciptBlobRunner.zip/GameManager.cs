using UnityEngine;

public class GameManager : MonoBehaviour 
{
    [Header("References")] 
    public GameHUD gameHUD;
    public BlobController playerController;

    [Header("Game Stats")]
    private int currentBiomass = 0;
    private int coinsCollected = 0;
    private int bigResourcesCollected = 0; 
    private float distanceTraveled = 0f; 

    void Start() 
    {
        InitializeGame(); 
    }

    void Update() 
    {
        distanceTraveled += Time.deltaTime * 10f;
        gameHUD.UpdateDistance(distanceTraveled);
    }

    void InitializeGame()
    {
        currentBiomass = 0; 
        coinsCollected = 0; 
        bigResourcesCollected = 0; 
        distanceTraveled = 0f;

        gameHUD.UpdateBiomass(0); 
        gameHUD.UpdateCoinCounter(0); 
        gameHUD.UpdateBigResourceCounter(0); 
        gameHUD.UpdateDistance(0f); 
    }

    public void AddCoin(int value = 1) 
    {
        coinsCollected += value; 
        currentBiomass += value;

        gameHUD.UpdateCoinCounter(coinsCollected); 
        gameHUD.UpdateBiomass(currentBiomass); 
    }

    public void AddBigResource(int value = 10) 
    {
        bigResourcesCollected++; 
        currentBiomass += value; 

        gameHUD.UpdateBigResourceCounter(bigResourcesCollected); 
        gameHUD.UpdateBiomass(currentBiomass); 
    }

    public void HitObstacle() 
    {
        currentBiomass -= 50; 
        if (currentBiomass < 0) currentBiomass = 0; 

        gameHUD.UpdateBiomass(currentBiomass); 

        if (currentBiomass <= 0) 
        {
            TriggerGameOver(); 
        }
    }

    void TriggerGameOver() 
    {
       
        Time.timeScale = 0f; 

       
    }

    
    public void RestartGame()
    {
        Time.timeScale = 1f; 
        InitializeGame(); 
    }
}
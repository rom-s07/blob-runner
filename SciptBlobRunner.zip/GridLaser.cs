using UnityEngine;

public class LaserGrid : BaseLaser
{
    [Header("Configuration Grille")]
    [SerializeField] private float gridHeight = 5f; 
    [SerializeField] private float gridWidth = 2f;
    [SerializeField] private float gridThickness = 0.1f;
    [SerializeField] private int verticalLineCount = 5;

    [Header("R�f�rences")]
    [SerializeField] private LineRenderer[] gridLines;
    [SerializeField] private BoxCollider gridCollider;

    private void Start()
    {
        InitializeGrid();
    }
    private void InitializeGrid()
    {
        gridCollider.size = new Vector3(gridWidth, gridHeight, gridThickness);
        gridCollider.center = new Vector3(gridWidth * 0.5f, gridHeight * 0.5f, 0);

        CreateGridVisual();
    }

    private void CreateGridVisual()
    {
        float spacingBetweenLines = gridWidth / (verticalLineCount - 1);

        for (int i = 0; i < Mathf.Min(gridLines.Length, verticalLineCount); i++)
        {
            LineRenderer line = gridLines[i];
            line.positionCount = 2; 
            float xPosition = i * spacingBetweenLines;

            line.SetPosition(0, new Vector3(xPosition, 0, 0));
            line.SetPosition(1, new Vector3(xPosition, gridHeight, 0));
        }
    }

    private void OnTriggerStay(Collider other)
    {
        if (((1 << other.gameObject.layer) & playerMask) != 0)
        {
            BiomassManager biomass = other.GetComponent<BiomassManager>();
            if (biomass != null)
            {
                if (!IsBlobInPuddleMode())
                {
                    ApplyDamage(biomass); 
                }
            }
        }
    }
}

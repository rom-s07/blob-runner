using UnityEngine;

public class CollectibleBiomass : MonoBehaviour
{
    [Header("VALEUR DE BIOMASSE")]
    [SerializeField] private int biomassValue = 1;

    [Header("EFFETS VISUELS ET SONORES")]
    [SerializeField] private ParticleSystem collectEffect;
    [SerializeField] private AudioClip collectSound;

    [Header("PARAMETRES D'ANIMATION")]
    [SerializeField] private float rotationSpeed = 90f;
    [SerializeField] private float floatHeight = 0.5f;
    [SerializeField] private float floatSpeed = 2f;

    public int BiomassValue
    {
        get { return biomassValue; }
    }


    private Vector3 startPosition;
    void Start()
    {
        startPosition = transform.position;
    }

    void Update()
    {
        transform.Rotate(0, rotationSpeed * Time.deltaTime, 0);

        Vector3 newPos = startPosition;
        newPos.y += Mathf.Sin(Time.time * floatSpeed) * floatHeight;
        transform.position = newPos;
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            BiomassManager biomassManager = other.GetComponent<BiomassManager>();

            if (biomassManager != null)
            {
                biomassManager.AddBiomass(biomassValue);

                PlayCollectionEffects();

                Destroy(gameObject);
            }
        }
    }

    private void PlayCollectionEffects()
    {
        if (collectEffect != null)
            Instantiate(collectEffect, transform.position, Quaternion.identity);

        if (collectSound != null)
            AudioSource.PlayClipAtPoint(collectSound, transform.position);
    }
}
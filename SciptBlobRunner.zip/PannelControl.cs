using UnityEngine;

public class PanneauCommande : MonoBehaviour
{
    [Header("Portes � Contr�ler")]
    [SerializeField] private PorteAutomatique[] portesAActiver; 

    [Header("Effets d'Activation")]
    [SerializeField] private Material materialActive;
    [SerializeField] private ParticleSystem activationEffect;
    [SerializeField] private AudioClip activationSound;

    private bool estActive = false;
    private Renderer rend;
    private Material materialOriginal;

    private void Start()
    {
        rend = GetComponent<Renderer>();
        if (rend != null)
        {
            materialOriginal = rend.material;
        }
    }

    
    public void ActiverPortes()
    {
        if (estActive) return; 

        estActive = true;
        Debug.Log("Panneau de contr�le activ� !");

        if (rend != null && materialActive != null)
        {
            rend.material = materialActive;
        }

        if (activationEffect != null)
        {
            Instantiate(activationEffect, transform.position, Quaternion.identity);
        }

        if (activationSound != null)
        {
            AudioSource.PlayClipAtPoint(activationSound, transform.position);
        }

        foreach (PorteAutomatique porte in portesAActiver)
        {
            if (porte != null)
            {
                porte.OuvrirPorte();
            }
        }
    }
}
using UnityEngine;
using System.Collections;

public class BlobController : MonoBehaviour
{
    [Header("MOUVEMENT AUTOMATIQUE")]
    [SerializeField] private float forwardSpeed = 5f; 
    [SerializeField] private float strafeSpeed = 8f;  

    [Header("LIMITES LATÉRALES")]
    [SerializeField] private float leftBound = -4f;   
    [SerializeField] private float rightBound = 4f;   
    [SerializeField] private bool enableBounds = true;

    [Header("RÉFÉRENCES")]
    [SerializeField] private TubeLangue tongueSystem;
    [SerializeField] private JumpBlob jumpSystem;

    [Header("RALENTISSEMENT")]
    [SerializeField] private float slowDuration = 2f;
    [SerializeField] private float slowFactor = 0.5f;

    private bool isSlowed = false;
    private float currentForwardSpeed;
    private Rigidbody rb;

    void Start()
    {
        rb = GetComponent<Rigidbody>();
        currentForwardSpeed = forwardSpeed;

        if (rb != null)
        {
            rb.freezeRotation = true; 
        }
    }

    void Update()
    {
        HandleStrafe(); 
        HandleActions(); 
        ApplyBounds();   
    }

    void FixedUpdate()
    {
        ApplyAutomaticMovement(); 
    }

    private void ApplyAutomaticMovement()
    {
        if (rb != null)
        {
            Vector3 currentVelocity = rb.linearVelocity;
            Vector3 newVelocity = new Vector3(currentVelocity.x, currentVelocity.y, currentForwardSpeed);

            rb.linearVelocity = newVelocity;
        }
        else
        {
            transform.Translate(Vector3.forward * currentForwardSpeed * Time.deltaTime);
        }
    }

    private void HandleStrafe()
    {
        float strafeInput = Input.GetAxis("Horizontal");

        if (strafeInput != 0 && rb != null)
        {
            Vector3 currentVelocity = rb.linearVelocity;

            Vector3 newVelocity = new Vector3(strafeInput * strafeSpeed, currentVelocity.y, currentVelocity.z);

            rb.linearVelocity = newVelocity;
        }
    }

    private void ApplyBounds()
    {
        if (!enableBounds) return; 

        Vector3 currentPosition = transform.position;

        if (currentPosition.x < leftBound)
        {
            currentPosition.x = leftBound;
            if (rb != null) rb.linearVelocity = new Vector3(0, rb.linearVelocity.y, rb.linearVelocity.z);
        }
        else if (currentPosition.x > rightBound)
        {
            currentPosition.x = rightBound;
            if (rb != null) rb.linearVelocity = new Vector3(0, rb.linearVelocity.y, rb.linearVelocity.z);
        }

        transform.position = currentPosition;
    }

    private void HandleActions()
    {
        if (Input.GetKeyDown(KeyCode.Space))
        {
            jumpSystem.Jump();
        }

        if (Input.GetMouseButtonDown(0))
        {
            tongueSystem.StartTongueExtension();
        }
    }

    public void ApplySlow()
    {
        if (isSlowed) return;
        StartCoroutine(SlowCoroutine());
    }

    private IEnumerator SlowCoroutine()
    {
        isSlowed = true;
        currentForwardSpeed = forwardSpeed * slowFactor;

        yield return new WaitForSeconds(slowDuration);

        currentForwardSpeed = forwardSpeed;
        isSlowed = false;
    }

    public void ResetVelocity()
    {
        if (rb != null)
        {
            Vector3 currentVelocity = rb.linearVelocity;
            rb.linearVelocity = new Vector3(currentVelocity.x, currentVelocity.y, currentForwardSpeed);
        }
    }

    public void SetBounds(float newLeftBound, float newRightBound)
    {
        leftBound = newLeftBound;
        rightBound = newRightBound;
    }

    public void EnableBounds(bool enabled)
    {
        enableBounds = enabled;
    }
}
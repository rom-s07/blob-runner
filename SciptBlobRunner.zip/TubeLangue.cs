using UnityEngine;
using System.Collections;

public class TubeLangue : MonoBehaviour
{
    [Header("R�f�rences")]
    [SerializeField] private Camera cam; 
    [SerializeField] private Transform tongueOrigin;
    [SerializeField] private LineRenderer tongueRenderer;
    [SerializeField] private LayerMask interactableMask;
    [SerializeField] private JumpBlob jumpSystem; 

    [Header("Param�tres du Tube")]
    [SerializeField] private float maxTongueLength = 10f;
    [SerializeField] private float extendSpeed = 20f; 
    [SerializeField] private float retractSpeed = 15f;
    [SerializeField] private float cooldown = 0.8f;
    [SerializeField] private float tongueWidth = 0.3f;

    private Vector3 targetPoint; 
    private bool isExtending = false;
    private bool canUse = true; 
    private Coroutine currentTongueCoroutine;

    void Start()
    {
        InitializeTongueRenderer();
    }

    void Update()
    {
        UpdateAimTarget();
    }

    private void InitializeTongueRenderer()
    {
        if (tongueRenderer == null)
        {
            tongueRenderer = gameObject.AddComponent<LineRenderer>(); 
        }

        tongueRenderer.positionCount = 2; 
        tongueRenderer.startWidth = tongueWidth; 
        tongueRenderer.endWidth = tongueWidth; 
        tongueRenderer.material = new Material(Shader.Find("Sprites/Default")); 
        tongueRenderer.startColor = Color.magenta; 
        tongueRenderer.endColor = Color.magenta;   
        tongueRenderer.enabled = false; 
    }

    private void UpdateAimTarget()
    {
        Vector3 mousePos = Input.mousePosition; 
        Ray camRay = cam.ScreenPointToRay(mousePos); 

        Vector3 raycastOrigin = camRay.origin; 
        Vector3 raycastDirection = camRay.direction; 
        float raycastDistance = maxTongueLength; 

        bool isCeiling = jumpSystem != null && jumpSystem.IsCeiling;

        if (isCeiling)
        {
            raycastDistance = maxTongueLength; 
        }

        if (Physics.Raycast(raycastOrigin, raycastDirection, out RaycastHit hit, raycastDistance, interactableMask))
        {
            targetPoint = hit.point; 
        }
        else
        {
            targetPoint = raycastOrigin + raycastDirection * raycastDistance; 
        }

        Debug.DrawRay(raycastOrigin, raycastDirection * raycastDistance, Color.yellow);
    }

    public void StartTongueExtension()
    {
        if (!canUse || isExtending) return; 

        if (currentTongueCoroutine != null) 
        {
            StopCoroutine(currentTongueCoroutine); 
        }

        currentTongueCoroutine = StartCoroutine(TongueExtensionSequence()); 
    }

    private IEnumerator TongueExtensionSequence()
    {
        isExtending = true; 
        canUse = false; 

        yield return StartCoroutine(ExtendTongue()); 
        yield return new WaitForSeconds(0.1f); 
        yield return StartCoroutine(RetractTongue()); 

        yield return new WaitForSeconds(cooldown); 

        canUse = true; 
        isExtending = false; 
    }

    private IEnumerator ExtendTongue()
    {
        tongueRenderer.enabled = true; 
        Vector3 startPos = tongueOrigin.position; 

        Vector3 direction;
        bool isCeiling = jumpSystem != null && jumpSystem.IsCeiling;

        if (isCeiling)
        {
            direction = (targetPoint - startPos).normalized;

            if (Mathf.Abs(direction.y) < 0.3f) 
            {
                direction = new Vector3(direction.x, -0.7f, direction.z).normalized; 
            }
        }
        else
        {
            direction = (targetPoint - startPos).normalized;
        }

        float actualDistance = Mathf.Min(Vector3.Distance(startPos, targetPoint), maxTongueLength); 
        Vector3 endPoint = startPos + direction * actualDistance; 

        float distance = 0f; 

        while (distance < actualDistance)
        {
            distance += extendSpeed * Time.deltaTime; 
            distance = Mathf.Min(distance, actualDistance); 

            float t = distance / actualDistance; 
            Vector3 currentEndPoint = Vector3.Lerp(startPos, endPoint, t); 

            tongueRenderer.SetPosition(0, startPos); 
            tongueRenderer.SetPosition(1, currentEndPoint); 

            DetectCollisionsDuringExtension(startPos, currentEndPoint); 

            yield return null; 
        }
    }

    private void DetectCollisionsDuringExtension(Vector3 start, Vector3 end)
    {
        Vector3 direction = (end - start).normalized; 
        float distance = Vector3.Distance(start, end); 

        if (Physics.Raycast(start, direction, out RaycastHit hit, distance, interactableMask))
        {
            HandleTongueInteraction(hit.collider.gameObject); 
        }
    }

    private IEnumerator RetractTongue()
    {
        Vector3 startPos = tongueRenderer.GetPosition(0); 
        Vector3 endPos = tongueRenderer.GetPosition(1); 
        float initialDistance = Vector3.Distance(startPos, endPos); 
        float distance = initialDistance; 

        while (distance > 0.1f)
        {
            distance -= retractSpeed * Time.deltaTime; 
            distance = Mathf.Max(distance, 0f); 

            float t = distance / initialDistance; 
            Vector3 currentEndPoint = Vector3.Lerp(startPos, endPos, t); 

            tongueRenderer.SetPosition(1, currentEndPoint); 

            yield return null; 
        }

        tongueRenderer.enabled = false; 
    }

    private void HandleTongueInteraction(GameObject interactedObject)
    {
        PanneauCommande panneau = interactedObject.GetComponent<PanneauCommande>();
        if (panneau != null)
        {
            panneau.ActiverPortes();
            Debug.Log(" Panneau de contr�le activ� par la langue!");
            return; 
        }

        HorizontalLaser laserHorizontal = interactedObject.GetComponent<HorizontalLaser>();
        if (laserHorizontal != null)
        {
            interactedObject.SetActive(false);
            Debug.Log("Laser horizontal d�sactiv� par la langue!");
            return; 
        }

        LaserGrid laserGrille = interactedObject.GetComponent<LaserGrid>();
        if (laserGrille != null)
        {
            interactedObject.SetActive(false);
            Debug.Log(" Grille laser d�sactiv�e par la langue!");
            return; 
        }

        CollectibleBiomass collectible = interactedObject.GetComponent<CollectibleBiomass>();
        if (collectible != null)
        {
            BiomassManager biomassManager = GetComponent<BiomassManager>();
            if (biomassManager != null)
            {
                biomassManager.AddBiomass(collectible.BiomassValue);
                Debug.Log($" Collectible ramass�! +{collectible.BiomassValue} biomasse");
            }
            else
            {
                Debug.LogWarning(" BiomassManager non trouv� sur le blob!");
            }

            Destroy(interactedObject);
            return; 
        }

        PorteAutomatique porte = interactedObject.GetComponent<PorteAutomatique>();
        if (porte != null && !porte.EstOuverte())
        {
            porte.OuvrirPorte();
            Debug.Log("Porte ouverte par la langue!");
            return; 
        }

        Debug.LogWarning($" La langue a touch� un objet non g�r�: {interactedObject.name}");

        Destroy(interactedObject);
    }
}
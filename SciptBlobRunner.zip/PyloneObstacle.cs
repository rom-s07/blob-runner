using UnityEngine;

public class PyloneObstacle : MonoBehaviour
{
    [Header("D�g�ts du Pyl�ne")]
    [SerializeField] private LayerMask playerMask; 

    private void OnTriggerEnter(Collider other)
    {
        if (((1 << other.gameObject.layer) & playerMask) != 0)
        {
            BiomassManager biomass = other.GetComponent<BiomassManager>();
            if (biomass != null)
            {
                biomass.TakeObstacleDamage();
                Debug.Log("Touch� par un pyl�ne! -1 biomasse + ralentissement");
                BlobController controller = other.GetComponent<BlobController>();
                if (controller != null)
                {
                    controller.ApplySlow(); 
                }
            }
        }
    }
}
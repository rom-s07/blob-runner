using UnityEngine;

public class PlaqueElectrique : MonoBehaviour
{
    [Header("D�g�ts de la Plaque")]
    [SerializeField] private LayerMask playerMask; 

    private void OnTriggerEnter(Collider other)
    {
        if (((1 << other.gameObject.layer) & playerMask) != 0)
        {
            BiomassManager biomass = other.GetComponent<BiomassManager>();
            if (biomass != null)
            {
                biomass.TakeObstacleDamage();
                Debug.Log("Touch� par une plaque �lectrique! -1 biomasse + ralentissement");
                BlobController controller = other.GetComponent<BlobController>();
                if (controller != null)
                {
                    controller.ApplySlow(); 
                }
            }
        }
    }
}
using UnityEngine;
using UnityEngine.UI;
using System;
using System.Collections;

public class BiomassManager : MonoBehaviour
{
    public static BiomassManager Instance;

    [Header("PARAM�TRES BIOMASSE")]
    [SerializeField] private int currentBiomass = 0;
    [SerializeField] private int maxBiomass = 300; 
    [SerializeField] private int obstacleDamage = 50; 

    [Header("TRANSFORMATIONS DU BLOB")]
    [SerializeField] private Vector3 baseScale = Vector3.one; 
    [SerializeField] private TransformationStage[] transformationStages; 

    [Header("INTERFACE UTILISATEUR")]
    [SerializeField] private Slider biomassSlider;
    [SerializeField] private Image[] milestoneMarkers; 
    public GameHUD gameHUD; 

    [Header("STATISTIQUES DE JEU")]
    private int coinsCollected = 0; 
    private int bigResourcesCollected = 0; 
    private float distanceTraveled = 0f; 

    [Header("ANTI-ENFONCEMENT")]
    [SerializeField] private JumpBlob jumpSystem;
    [SerializeField] private float groundLevel = 0f;
    [SerializeField] private float ceilingLevel = 5f;
    [SerializeField] private float snapMargin = 0.1f;

    [Header("EFFETS DE D�G�TS")]
    [SerializeField] private Color damageFlashColor = Color.red;
    [SerializeField] private float flashDuration = 0.1f;
    [SerializeField] private int flashCount = 3;

    public event Action<int> OnBiomassChanged;
    public event Action<int> OnTransformationChanged;

    [System.Serializable]
    public struct TransformationStage
    {
        public int requiredBiomass;
        public float sizeMultiplier;
        public Color stageColor;
    }

    void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject); 
        }
        else
        {
            Destroy(gameObject);
            return;
        }
    }

    void Start()
    {
        InitializeDefaultStages();
        UpdateUI();
        transform.localScale = baseScale;

        if (gameHUD != null)
        {
            gameHUD.UpdateBiomass(currentBiomass);
            gameHUD.UpdateCoinCounter(0); 
            gameHUD.UpdateBigResourceCounter(0);
            gameHUD.UpdateDistance(0f);
            gameHUD.UpdateShapeIndicator(GetCurrentStage(currentBiomass) + 1); 
        }
    }

    void Update()
    {
        distanceTraveled += Time.deltaTime * 10f;

        if (gameHUD != null)
            gameHUD.UpdateDistance(distanceTraveled);
    }

    private void InitializeDefaultStages()
    {
        if (transformationStages == null || transformationStages.Length == 0)
        {
            transformationStages = new TransformationStage[]
            {
                new TransformationStage { requiredBiomass = 50, sizeMultiplier = 1.25f, stageColor = Color.green },
                new TransformationStage { requiredBiomass = 150, sizeMultiplier = 1.50f, stageColor = Color.blue }, 
                new TransformationStage { requiredBiomass = 300, sizeMultiplier = 2.00f, stageColor = Color.red } 
            };
        }
    }

    public void AddBiomass(int amount)
    {
        int oldBiomass = currentBiomass;
        currentBiomass = Mathf.Min(currentBiomass + amount, maxBiomass);
        UpdateUI();
        OnBiomassChanged?.Invoke(currentBiomass); 
        CheckTransformation(oldBiomass, currentBiomass);

        if (gameHUD != null)
        {
            gameHUD.UpdateBiomass(currentBiomass);
            gameHUD.UpdateShapeIndicator(GetCurrentStage(currentBiomass) + 1); 
        }
    }

    public void RemoveBiomass(int amount)
    {
        int oldBiomass = currentBiomass;
        currentBiomass = Mathf.Max(currentBiomass - amount, 0); 

        if (currentBiomass <= 0)
        {
            GameOver();
        }

        UpdateUI();
        OnBiomassChanged?.Invoke(currentBiomass); 
        CheckTransformation(oldBiomass, currentBiomass); 

        if (gameHUD != null)
        {
            gameHUD.UpdateBiomass(currentBiomass); 
            gameHUD.UpdateShapeIndicator(GetCurrentStage(currentBiomass) + 1); 
        }
    }

    public void CollectCoin()
    {
        coinsCollected++; 
        AddBiomass(1); 

        if (gameHUD != null)
            gameHUD.UpdateCoinCounter(coinsCollected);
    }

    public void CollectBigResource()
    {
        bigResourcesCollected++;
        AddBiomass(10);

        if (gameHUD != null)
            gameHUD.UpdateBigResourceCounter(bigResourcesCollected);
    }

    public void TakeObstacleDamage()
    {
        RemoveBiomass(obstacleDamage);
        StartDamageFlash();
    }

    public void StartDamageFlash()
    {
        StartCoroutine(DamageFlashCoroutine());
    }

    private IEnumerator DamageFlashCoroutine()
    {
        Renderer blobRenderer = GetComponent<Renderer>();
        if (blobRenderer == null) yield break; 

        Material blobMaterial = blobRenderer.material; 
        Color originalColor = blobMaterial.color;

        for (int i = 0; i < flashCount; i++)
        {
            blobMaterial.color = damageFlashColor; 
            yield return new WaitForSeconds(flashDuration); 
            blobMaterial.color = originalColor; 
            yield return new WaitForSeconds(flashDuration); 
        }

        blobMaterial.color = originalColor;
    }

    // V�rifie et applique les transformations entre deux valeurs de biomasse
    private void CheckTransformation(int oldBiomass, int newBiomass)
    {
        int currentStage = GetCurrentStage(newBiomass); 
        int previousStage = GetCurrentStage(oldBiomass); 
        if (currentStage != previousStage)
        {
            ApplyTransformation(currentStage); 
            OnTransformationChanged?.Invoke(currentStage); 
        }
    }

    private int GetCurrentStage(int biomass)
    {
        int currentStage = -1; 

        for (int i = 0; i < transformationStages.Length; i++)
        {
            if (biomass >= transformationStages[i].requiredBiomass)
            {
                currentStage = i; 
            }
        }

        return currentStage; 
    }

    private void ApplyTransformation(int stageIndex)
    {
        Vector3 oldScale = transform.localScale; 
        Vector3 newScale; 

        if (stageIndex >= 0 && stageIndex < transformationStages.Length)
        {
            float multiplier = transformationStages[stageIndex].sizeMultiplier; 
            newScale = baseScale * multiplier; 
            Debug.Log($"Transformation au stade {stageIndex + 1} - Taille: x{multiplier}"); 
        }
        else
        {
            newScale = baseScale; 
            Debug.Log("Retour � la taille de base"); 
        }

        transform.localScale = newScale;
        CorrectPositionAfterScaling(oldScale, newScale); 
        SnapToCorrectLevel(); 
    }

    private void CorrectPositionAfterScaling(Vector3 oldScale, Vector3 newScale)
    {
        float heightDifference = (newScale.y - oldScale.y) * 0.5f; 

        if (Mathf.Abs(heightDifference) < 0.01f) return; 

        Vector3 newPosition = transform.position; 
        bool isCeiling = jumpSystem != null && jumpSystem.IsCeiling; 

        if (isCeiling) 
        {
            newPosition.y -= heightDifference; 
        }
        else 
        {
            newPosition.y += heightDifference; 
        }

        transform.position = newPosition; 
    }

    private void SnapToCorrectLevel()
    {
        float blobBottom = transform.position.y - (transform.localScale.y * 0.5f); 
        float blobTop = transform.position.y + (transform.localScale.y * 0.5f);
        bool isCeiling = jumpSystem != null && jumpSystem.IsCeiling;

        if (isCeiling) 
        {
            if (blobTop > ceilingLevel - snapMargin) 
            {
                float correction = ceilingLevel - blobTop; 
                transform.position = new Vector3(transform.position.x, transform.position.y + correction, transform.position.z); // Applique la correction
            }
        }
        else 
        {
            if (blobBottom < groundLevel + snapMargin) 
            {
                float correction = groundLevel - blobBottom;
                transform.position = new Vector3(transform.position.x, transform.position.y + correction, transform.position.z); // Applique la correction
            }
        }
    }

    private void UpdateUI()
    {
        if (biomassSlider != null)
        {
            biomassSlider.value = (float)currentBiomass / maxBiomass; 
        }

        UpdateMilestoneMarkers(); 
    }

    private void UpdateMilestoneMarkers()
    {
        for (int i = 0; i < milestoneMarkers.Length && i < transformationStages.Length; i++)
        {
            if (milestoneMarkers[i] != null) 
            {
                bool shouldShow = currentBiomass >= transformationStages[i].requiredBiomass; 
                milestoneMarkers[i].gameObject.SetActive(shouldShow);
            }
        }
    }

    public int GetCurrentBiomass()
    {
        return currentBiomass;
    }

    public void CollectWithTongue(int biomassValue)
    {
        AddBiomass(biomassValue); 
    }

    private void GameOver()
    {
        Debug.Log("Game Over - Biomasse �puis�e!"); 

     

        Time.timeScale = 0f;
    }

    public void RestartGame()
    {
        currentBiomass = 0;
        coinsCollected = 0;
        bigResourcesCollected = 0;
        distanceTraveled = 0f;

        Time.timeScale = 1f;

        if (gameHUD != null)
        {
            gameHUD.UpdateBiomass(0);
            gameHUD.UpdateCoinCounter(0);
            gameHUD.UpdateBigResourceCounter(0);
            gameHUD.UpdateDistance(0f);
            gameHUD.UpdateShapeIndicator(0);
        }

        transform.localScale = baseScale;

        UpdateUI();
    }
}